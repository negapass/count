#!c:\users\이주홍\desktop\멋쟁이 사자처럼\190401실습\myvenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
